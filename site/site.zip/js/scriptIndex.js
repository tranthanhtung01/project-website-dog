function openNav() {
	document.getElementById("mySidenav").style.width = "252px";
	document.getElementById("main").style.marginLeft = "252px";
}

function closeNav() {
	document.getElementById("mySidenav").style.width = "0";
	document.getElementById("main").style.marginLeft= "0";
}

$(document).ready(function(){
    $("#sub-pro-0").hover(function(){
        $("#btn-0").toggle(400);
    });
    $("#sub-pro-1").hover(function(){
        $("#btn-1").toggle(400);
    });
    $("#sub-pro-2").hover(function(){
        $("#btn-2").toggle(400);
    });
     $("#sub-pro-3").hover(function(){
        $("#btn-3").toggle(400);
    });
      $("#sub-pro-4").hover(function(){
        $("#btn-4").toggle(400);
    });
       $("#sub-pro-5").hover(function(){
        $("#btn-5").toggle(400);
    });
       $("#sub-pro-6").hover(function(){
        $("#btn-6").toggle(400);
    });
       $("#sub-pro-7").hover(function(){
        $("#btn-7").toggle(400);
    });
});
// Back to Top
$(window).scroll(function(){
    if($(this).scrollTop() != 0){
        $('#bttop').fadeIn();
    }
    else
        $('#bttop').fadeOut();
})

$('#bttop').click(function(){
    $('html').animate({
        scrollTop:0
    },500);
});
