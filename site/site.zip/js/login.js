
$('#btn-login').click(function () {
    $('#login-modal').modal('show');
    });

$('#btn-register').click(function () {
    $('#register').modal('show');
    });
$('#chuaLaThanhVien').click(function () {
        $('#login-modal').modal('hide');
        $('#register').modal('show');
    });
$('.showTogether').click(function() {
    $('#shoppingCart').toggle();
});
$('#btn-category').click(function () {
        $('#Categories').toggle(400);
    });
function checkform(){
	var username = document.getElementById("ten_khach_hang").value;
	var pass = document.getElementById("mat_khau").value;
	var repass = document.getElementById("mat_khau_2").value;
	if(pass!= repass){
		alert("Mật khẩu sai!");
	}
}
$("#submit").click(function () {
        var ten_khach_hang = $("#ten_khach_hang").val();
        var ten_dang_nhap = $("#ten_dang_nhap").val();
        var mat_khau = $("#mat_khau").val();
        var mat_khau_2 = $("#mat_khau_2").val();
        var email = $("#email").val();
        var sdt = $("#sdt").val();
        if (ten_khach_hang === '' || ten_dang_nhap === '' || mat_khau === '' || mat_khau_2 === ''
                || email === '' || sdt === '') {
            alert("Vui lòng điền đầy đủ thông tin");
        } else {
            alert("đăng nhập thành công");
        }
});

