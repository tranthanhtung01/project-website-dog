
function hienthi(type_design){
	switch (type_design) {
		case "all":
			$(".corgi").show("slow");
			$(".husky").show("slow");
			$(".mountain").show("slow");
			break;
		case "corgi":
			$(".corgi").show("slow");
			$(".husky").hide("slow");
			$(".mountain").hide("slow");
			break;
		case "husky":
			$(".corgi").hide("slow");
			$(".husky").show("slow");
			$(".mountain").hide("slow");
			break;
		case "mountain":
			$(".corgi").hide("slow");
			$(".husky").hide("slow");
			$(".mountain").show("slow");
			break;
		default:
			// statements_def
			break;
	}
}
